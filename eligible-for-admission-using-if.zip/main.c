/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int math,physics,total_mark;
    scanf("%d %d %d",&math,&physics,&total_mark);
    if((math>60 && physics>50) || (total_mark>200)){
        printf("eligible for admission");
    }else{
        printf("not eligible for admission");
    }

    return 0;
}
