
#include <stdio.h>

int main()
{
    int ch = 64;
    for(int i=0;i<=25;i++){
        ch+=1;
        printf("%c ",ch);
    }

    return 0;
}

