
#include <stdio.h>

int main()
{
    char ch;
    scanf("%c",&ch);
    
    if(ch>='a' && ch<='z'){
        printf("Lower case");
    }else if(ch >= 'A' && ch<='Z'){
        printf("Uppercase");
    }else{
        printf("Alpha Numeric");
    }

    return 0;
}
